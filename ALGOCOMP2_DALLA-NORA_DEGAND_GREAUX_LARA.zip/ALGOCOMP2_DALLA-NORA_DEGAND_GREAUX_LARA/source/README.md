# MiniProjet2
## Team members :
### DEGAND Sébastien, DALLA-NORA Enzo, GRÉAUX Thomas, LARA Jérémy

Dans le dossier 'doc' se trouve le sujet ainsi que l'analyse de notre travail
Dans le dossier 'exemples' se trouve des fichiers textes representant les donnees du probleme
Dans le dossier 'source' se trouve les fichiers source, en C++

Pour generer les executables, il suffit de faire la commande 'make'
